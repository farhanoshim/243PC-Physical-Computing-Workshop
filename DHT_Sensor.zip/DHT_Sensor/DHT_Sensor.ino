/* COMSC 243PC: Temperature & Humidity Display
 * Using DHT11 sensor and SSD1306 OLED
 */
 
#include <TinyDHT.h>

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>


#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_ADDR 0x3C

#define DHTPIN 2
#define DHTTYPE DHT11

Adafruit_SSD1306 lcd(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire);
DHT dht(DHTPIN, DHTTYPE);

void setup() {

  Serial.begin(9600);

  if(!lcd.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    while(true); // stop if OLED fails
  }

  lcd.clearDisplay();
  lcd.setTextColor(SSD1306_WHITE);
  lcd.setTextSize(1.5);

  dht.begin();
}

void loop() {

  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();

  lcd.clearDisplay();

  lcd.setCursor(0,0);
  lcd.print("Temp:");

  lcd.setCursor(50,0);
  lcd.print(temperature);
  lcd.print(" C");

  lcd.setCursor(0,40);
  lcd.print("Hum:");

  lcd.setCursor(50,40);
  lcd.print(humidity);
  lcd.print(" %");

  lcd.display();

  delay(2000);
}
