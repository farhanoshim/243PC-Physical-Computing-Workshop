/* COMSC 243PC: Physical Computing Workshop
 * Koch Curve Fractal with Button Control (Arduino Uno)
 *
 * This program draws a Koch curve fractal on a 128x64 I2C SSD1306 OLED display.
 * Each time the pushbutton is pressed, the recursion level increases,
 * changing the complexity of the fractal.
 *
 * Hardware:
 * - Arduino Uno
 * - SSD1306 128x64 I2C OLED (address 0x3C)
 * - Pushbutton connected to digital pin 2 (using INPUT_PULLUP)
 *
 * Libraries Used:
 * - Adafruit_GFX
 * - Adafruit_SSD1306
 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_ADDR 0x3C

#define BUTTON 2   // Use digital pin 2 (avoid pin 0)

Adafruit_SSD1306 lcd(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire);

byte prev_state = HIGH;
byte maxlevel = 0;

void setup() {
  Wire.begin();

  lcd.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR);
  lcd.clearDisplay();

  drawKoch(0, 0, 126, 0, 0);
  lcd.display();

  pinMode(BUTTON, INPUT_PULLUP);
}

void loop() {
  byte curr_state = digitalRead(BUTTON);

  if (prev_state == HIGH && curr_state == LOW) {
    maxlevel = (maxlevel + 1) % 5;

    lcd.clearDisplay();
    drawKoch(0, 0, 126, 0, 0);
    lcd.display();

    delay(250); // simple debounce
  }

  prev_state = curr_state;
}

void drawKoch(float x0, float y0, float x1, float y1, int level) {

  if (level >= maxlevel) {
    lcd.drawLine(x0, 40 - y0, x1, 40 - y1, SSD1306_WHITE);
    return;
  }

  float x2 = x0 * 2 / 3 + x1 * 1 / 3;
  float y2 = y0 * 2 / 3 + y1 * 1 / 3;

  float x4 = x0 * 1 / 3 + x1 * 2 / 3;
  float y4 = y0 * 1 / 3 + y1 * 2 / 3;

  float x3 = (x4 - x2) / 2 - (y4 - y2) * 0.866 + x2;
  float y3 = (x4 - x2) * 0.866 + (y4 - y2) / 2 + y2;

  drawKoch(x0, y0, x2, y2, level + 1);
  drawKoch(x2, y2, x3, y3, level + 1);
  drawKoch(x3, y3, x4, y4, level + 1);
  drawKoch(x4, y4, x1, y1, level + 1);
}
