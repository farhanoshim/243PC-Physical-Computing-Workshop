/* COMSC 243PC: Physical Computing Workshop
 * Melody Player (Arduino Uno)
 *
 * This program plays several classical melodies using a piezo buzzer connected
 * to an Arduino Uno. It generates tones of different frequencies using the
 * built-in tone() function and controls note duration using delay().
 * The melodies include Ode to Joy, Minuet in G Major, and Flight of the Bumblebee.
 */
 
#include "pitches.h"

#define BUZZ 8

// ---------------- ODE TO JOY ----------------
int ode_to_joy_melody[] = {
  NOTE_E4, NOTE_E4, NOTE_F4, NOTE_G4, NOTE_G4, NOTE_F4, NOTE_E4, NOTE_D4,
  NOTE_C4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_E4, NOTE_D4, NOTE_D4,
  NOTE_E4, NOTE_E4, NOTE_F4, NOTE_G4, NOTE_G4, NOTE_F4, NOTE_E4, NOTE_D4,
  NOTE_C4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_D4, NOTE_C4, NOTE_C4
};

float ode_to_joy_duration[] = {
  4,4,4,4,4,4,4,4,
  4,4,4,4,2.67,8,2,
  4,4,4,4,4,4,4,4,
  4,4,4,4,2.67,8,2
};

// ---------------- MINUTE MELODY ----------------
int minute_melody[] = {
  NOTE_G4, NOTE_C4, NOTE_D4, NOTE_E4, NOTE_F4, NOTE_G4,
  NOTE_C4, NOTE_C4, NOTE_A4, NOTE_F4, NOTE_G4, NOTE_A4,
  NOTE_B4, NOTE_C5
};

float minute_duration[] = {
  4,8,8,8,8,4,
  4,4,4,8,8,8,
  8,4
};

// ---------------- BUMBLEBEE (SHORTENED) ----------------
int bumblebee_melody[] = {
  NOTE_E4, NOTE_DS4, NOTE_D4, NOTE_CS4,
  NOTE_C4, NOTE_F4, NOTE_E4, NOTE_DS4
};

float bumblebee_duration[] = {
  16,16,16,16,
  16,16,16,16
};

// ---------------- PLAY FUNCTION ----------------
void play_tune(int melody[], float duration[], int num_notes)
{
  for (int i = 0; i < num_notes; i++)
  {
    int noteDuration = 1000 / duration[i];

    tone(BUZZ, melody[i]);
    delay(noteDuration);

    noTone(BUZZ);

    delay(noteDuration * 0.3);
  }
}

// ---------------- SETUP ----------------
void setup()
{
  Serial.begin(9600);
  pinMode(BUZZ, OUTPUT);

  play_tune(ode_to_joy_melody,
            ode_to_joy_duration,
            sizeof(ode_to_joy_melody)/sizeof(int));

  play_tune(minute_melody,
            minute_duration,
            sizeof(minute_melody)/sizeof(int));

  play_tune(bumblebee_melody,
            bumblebee_duration,
            sizeof(bumblebee_melody)/sizeof(int));
}

void loop()
{
}
