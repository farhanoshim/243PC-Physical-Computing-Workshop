#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 lcd(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// Button pins
#define BACKWARD 3
#define FORWARD 2
#define AXIS 4

int x = 64;
int y = 32;

void setup() {

  lcd.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  lcd.clearDisplay();

  // initialize buttons
  pinMode(BACKWARD, INPUT_PULLUP);
  pinMode(FORWARD, INPUT_PULLUP);
  pinMode(AXIS, INPUT_PULLUP);
}

void loop() {

  // TODO: update x and y based on button status

  lcd.drawPixel(x, y, SSD1306_WHITE);
  lcd.display();

  delay(50);
}
