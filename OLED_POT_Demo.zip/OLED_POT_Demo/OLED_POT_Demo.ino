/* COMSC 243PC: Physical Computing Workshop
 * Potentiometer Reading Display on OLED (Arduino Uno)
 *
 * This program reads the value of a potentiometer connected to A0
 * and displays the scaled value on a 128x64 I2C SSD1306 OLED.
 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_ADDR 0x3C
#define POT A0

Adafruit_SSD1306 lcd(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire);

void setup() {
  Wire.begin();

  if(!lcd.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    for(;;); // Stop if display fails
  }

  lcd.clearDisplay();
  lcd.setTextColor(SSD1306_WHITE);
  lcd.setTextSize(2);  // Bigger text
}

void loop() {
  int value = analogRead(POT) / 4;  // Scale 0–1023 to 0–255

  lcd.clearDisplay();               // Clear previous frame
  lcd.setCursor(0, 0);
  lcd.print(value);

  lcd.display();                    // Update screen
  delay(100);
}
