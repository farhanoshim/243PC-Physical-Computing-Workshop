/* COMSC 243PC: Physical Computing Workshop
 * Potentiometer Reading Display on OLED (Arduino Uno)
 *
 * This program reads the value of a potentiometer connected to A0
 * and displays the scaled value on a 128x64 I2C SSD1306 OLED.
 */

#include <Wire.h>
#include <SSD1306Wire.h>

#define POT A0

// Arduino Uno: SDA = A4, SCL = A5
SSD1306Wire lcd(0x3C, A4, A5);

void setup() {
  Wire.begin();           // Initialize I2C
  lcd.init();
  lcd.flipScreenVertically();
  lcd.setFont(ArialMT_Plain_16); // Use larger font
}

void loop() {
  int value = analogRead(POT) / 4; // scale 0-1023 to ~0-255
  lcd.clear();                     // clear previous value
  lcd.drawString(0, 0, String(value));
  lcd.display();                   // push buffer to OLED
  delay(100);                      // small delay to reduce flicker
}
