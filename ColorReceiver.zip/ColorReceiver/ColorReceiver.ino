/* COMSC 243PC
 * Serial RGB → OLED + NeoPixel Ring (Arduino Uno)
 *
 * -------------------- CONNECTIONS --------------------
 *
 * OLED (SSD1306 I2C Display):
 *   VCC  → 5V
 *   GND  → GND
 *   SDA  → A4
 *   SCL  → A5
 *
 * NeoPixel (1 LED or Ring):
 *   VCC  → 5V
 *   GND  → GND
 *   DIN  → Pin 6
 *
 * -----------------------------------------------------
 * This program reads 3 bytes (R, G, B) from Serial
 * and:
 *   1) Displays the RGB values on the OLED
 *   2) Sets the NeoPixel color accordingly
 *
 * Note:
 * Serial baud rate must match sender (e.g., Processing)
 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_NeoPixel.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

// OLED (I2C: SDA=A4, SCL=A5)
Adafruit_SSD1306 lcd(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// NeoPixel
#define PIN_NEOP 6
Adafruit_NeoPixel pixel(1, PIN_NEOP, NEO_GRB + NEO_KHZ800);

void setup() {

  Serial.begin(115200);

  // OLED init
  if(!lcd.begin(SSD1306_SWITCHCAPVCC, 0x3C)){
    while(true); // stop if OLED fails
  }

  lcd.clearDisplay();
  lcd.setTextSize(2);
  lcd.setTextColor(SSD1306_WHITE);

  // NeoPixel init
  pixel.begin();
  pixel.clear();
  pixel.show();
}

void loop() {

  if (Serial.available() >= 3) {   // ensure 3 bytes available

    byte rgb[3];
    Serial.readBytes(rgb, 3);

    // Display on OLED
    lcd.clearDisplay();
    lcd.setCursor(0, 20);
    lcd.print("(");
    lcd.print(rgb[0]);
    lcd.print(",");
    lcd.print(rgb[1]);
    lcd.print(",");
    lcd.print(rgb[2]);
    lcd.print(")");
    lcd.display();

    // Set NeoPixel color
    pixel.setPixelColor(0, pixel.Color(rgb[0], rgb[1], rgb[2]));
    pixel.show();
  }
}
