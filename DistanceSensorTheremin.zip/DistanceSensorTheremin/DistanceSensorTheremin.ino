/* COMSC 243PC: Physical Computing Workshop
 * Ultrasonic Distance Sensor with OLED Display and Buzzer (Arduino Uno)
 *
 * This program measures distance using an HC-SR04 ultrasonic sensor and
 * displays the measured distance and corresponding sound frequency on a
 * 128x64 I2C SSD1306 OLED display. A buzzer generates a tone whose frequency
 * can be controlled based on the measured distance (similar to a simple
 * theremin-style instrument).
 *
 * Hardware:
 * - Arduino Uno
 * - HC-SR04 Ultrasonic Distance Sensor
 * - SSD1306 128x64 I2C OLED Display (address 0x3C)
 * - Piezo Buzzer connected to digital pin 9
 *
 * Connections:
 * - Ultrasonic TRIG  -> Digital Pin 5
 * - Ultrasonic ECHO  -> Digital Pin 6
 * - Buzzer           -> Digital Pin 9
 * - OLED SDA         -> A4
 * - OLED SCL         -> A5
 *
 * Libraries Used:
 * - Wire
 * - Adafruit_GFX
 * - Adafruit_SSD1306
 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// -------- Pin Definitions --------
#define TRIG   5
#define ECHO   6
#define BUZZER 9

void setup() {
  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);
  digitalWrite(TRIG, LOW);

  pinMode(BUZZER, OUTPUT);

  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.display();
}

// read distance sensor, return in units of centimeters
float readDistance() {
  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG, LOW);

  long duration = pulseIn(ECHO, HIGH, 30000);
  float distance = duration * 0.0343 / 2.0;
  return distance;
}

/* ======================================
 * DO NOT MODIFY ANYTHING ABOVE THIS LINE
 * ======================================
 */
 

#define K 5 // queue size
float queue[K] = {0};
int qindex = 0;

/* TODO: COMPLETE THE getAverage() FUNCTION BELOW */
float getAverage() {

}

void loop() {
  
  /* TODO: MODIFY THE LOOP FUNCTION */  
  float dist = readDistance();
  
  float freq = 220.0; // modify this line when working on Theremin

  tone(BUZZER, freq);

  /* The code below displays distance and frequency to LCD*/
  display.clearDisplay();
  display.setCursor(0, 0);
  display.print("Distance (cm):");
  display.println(dist);
  display.println("-----------");
  display.print("Frequency:");
  display.println(freq);
  display.display();
  
  delay(200); // remove this line when working on Theremin
}
