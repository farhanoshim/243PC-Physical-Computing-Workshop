#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// OLED display size
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

// I2C address of the display
#define OLED_ADDR 0x3C

// Create display object
Adafruit_SSD1306 lcd(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire);

void setup() {
  // Initialize I2C communication
  Wire.begin(); // Arduino Uno uses default SDA/SCL pins

  // Initialize the OLED
  if(!lcd.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println(F("SSD1306 allocation failed"));
    for(;;); // Stop here if OLED init fails
  }

  lcd.clearDisplay();
  lcd.setTextColor(SSD1306_WHITE);
  lcd.setTextSize(1); // normal 1:1 pixel scale
  lcd.setCursor(0,0); // top-left corner
  lcd.println("Hello World!");
  lcd.println("Hello 243 PC!");
  lcd.display();      // push buffer to the display
}

void loop() {
  // Nothing to do in loop
}
