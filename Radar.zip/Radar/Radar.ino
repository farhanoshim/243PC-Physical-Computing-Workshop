#include <Servo.h>

Servo myServo;  // Create a Servo object

const int servoPin = 12;  // servo connected to digital pin 12

#define TRIGGER_PIN 10  // Pin to trigger the ultrasonic pulse
#define ECHO_PIN 11     // Pin to receive the echo

void setup() {
  pinMode(TRIGGER_PIN, OUTPUT);  // Set the Trig pin as output
  pinMode(ECHO_PIN, INPUT);      // Set the Echo pin as input
  Serial.begin(9600);            // Start serial communication for debugging
  myServo.attach(servoPin);      // Defines on which pin is the servo attached
  myServo.write(90);             // Initial position set to 90 degrees
}

void loop() {
  // rotates the servo from 15 to 165 degrees
  for (int i = 15; i <= 165; i++) {
    myServo.write(i);
    delay(30);
    long distance = measureDistance();  // Call the function to measure distance
    Serial.print(i);                    // Sends the current degree into the Serial Port
    Serial.print(",");                  // Sends addition character right next to the previous value needed later in the Processing PDE for indexing
    Serial.print(distance);             // Sends the distance value into the Serial Port
    Serial.print(".");                  // Sends addition character right next to the previous value needed later in the Processing PDE for indexing
  }
  // Repeats the previous lines from 165 to 15 degrees
  for (int i = 165; i > 15; i--) {
    myServo.write(i);
    delay(30);
    long distance = measureDistance();  // Call the function to measure distance
    Serial.print(i);                    // Sends the current degree into the Serial Port
    Serial.print(",");                  // Sends addition character right next to the previous value needed later in the Processing PDE for indexing
    Serial.print(distance);             // Sends the distance value into the Serial Port
    Serial.print(".");                  // Sends addition character right next to the previous value needed later in the Processing PDE for indexing
  }
}

// Function to read the sensor data and calculate the distance
long measureDistance() {
  digitalWrite(TRIGGER_PIN, LOW);  // Ensure Trig pin is low before a pulse
  delayMicroseconds(2);
  digitalWrite(TRIGGER_PIN, HIGH);  // Send a high pulse
  delayMicroseconds(10);            // Pulse duration of 10 microseconds
  digitalWrite(TRIGGER_PIN, LOW);   // End the high pulse

  long duration = pulseIn(ECHO_PIN, HIGH);  // Measure the duration of high level on Echo pin
  long distance = duration * 0.034 / 2;     // Calculate the distance (in cm)
  return distance;
}
